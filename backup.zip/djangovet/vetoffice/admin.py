from django.contrib import admin

from .models import Owner, Patient

admin.site.register(Owner)
admin.site.register(Patient)
