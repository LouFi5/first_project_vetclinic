# Build Python Web Apps with Django

Hello! This GitHub repo is intended to be used with the article Deploy Your App to PythonAnywhere.

Make sure to follow the steps as outlined in the article to see how to use GitHub and PythonAnywhere for your deployment needs!

You're free to make changes on your own branch, but for the sake of consistency, we will not be merging any external pull requests. Thank you and happy coding!

